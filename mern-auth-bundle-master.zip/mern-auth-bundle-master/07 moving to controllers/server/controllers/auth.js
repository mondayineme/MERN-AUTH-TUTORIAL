exports.signup = (req, res) => {
    res.json({
        data: 'you hit signup endpoint yay from controllers'
    });
};
